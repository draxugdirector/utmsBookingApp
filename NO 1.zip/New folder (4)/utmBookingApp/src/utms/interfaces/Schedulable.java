package utms.interfaces;
public interface Schedulable{
    void Schedulable(String time);
}